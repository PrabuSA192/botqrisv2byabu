const settings = {
    TOKEN : '8337735658:AAHyZU71AFe_WcXNCco7YM53OelUb6GvI8Y',
    OWNER_ID : '6250933363',
    ADMIN_LINK : 'https://t.me/abuzycreative',
    CHANNEL_LINK : 'https://t.me/abuzytesti'
};
module.exports = settings;